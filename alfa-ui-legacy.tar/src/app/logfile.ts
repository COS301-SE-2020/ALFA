export interface Logfile {
    filename: string,
    date: string,
    content: string,
}
