export interface Article {
    kb_index: number,
    description: string,
    link: string,
    web_link: string,
    _id: string,
    votes: number
}

