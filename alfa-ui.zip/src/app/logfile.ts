export interface Logfile {
    filename: string,
    date: string,
    data: string,
}
