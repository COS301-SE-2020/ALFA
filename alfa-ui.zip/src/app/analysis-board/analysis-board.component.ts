import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-analysis-board',
  templateUrl: './analysis-board.component.html',
  styleUrls: ['./analysis-board.component.css']
})
export class AnalysisBoardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
