export interface Article {
    // title: string, // I would like this to have a title, urls can be long to display
    link: string,
}

